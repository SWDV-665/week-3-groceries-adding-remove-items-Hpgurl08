import React from "react";
import {
  IonList,
  IonItem,
  IonLabel,
} from "@ionic/react";

interface UserDetailsListProps {
  name: string;
  id: string;
}

const UserDetailsList: React.FC<UserDetailsListProps> = ({ name, id }) => {
  return (
    <IonList className="list">
      <IonItem className="item">
        <IonLabel className="label">Name:</IonLabel>
        {name}
      </IonItem>
      <IonItem className="item">
        <IonLabel className="label">ID:</IonLabel>
        {id}
      </IonItem>
    </IonList>
  );
};

export default UserDetailsList;
