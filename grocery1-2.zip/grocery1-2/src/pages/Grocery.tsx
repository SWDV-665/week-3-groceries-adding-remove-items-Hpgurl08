import React, { useState } from "react";
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButton,
  IonModal,
  IonIcon,
  IonInput,
  IonFab,
  IonFabButton,
  IonToast, // Import IonToast
} from "@ionic/react";
import { add } from "ionicons/icons";
import GroceryList from "../components/GroceryList";
import "./Grocery.css";

const Grocery: React.FC = () => {
  const [groceryItems, setGroceryItems] = useState<
    { name: string; quantity: string }[]
  >([
    { name: "Apples", quantity: "5" },
    { name: "Bananas", quantity: "3" },
    { name: "Milk", quantity: "1" },
    { name: "Bread", quantity: "2" },
    { name: "Eggs", quantity: "12" },
  ]);
  const [newItem, setNewItem] = useState<{ name: string; quantity: string }>({
    name: "",
    quantity: "",
  });
  const [showPopup, setShowPopup] = useState(false);
  const [showErrorToast, setShowErrorToast] = useState(false); // State for error toast

    const addItemToList = () => {
    if (newItem.name.trim() !== "" && newItem.quantity.trim() !== "") {
      // validate the quantity
      const parsedQuantity = parseInt(newItem.quantity, 10);
      if (!isNaN(parsedQuantity) && parsedQuantity > 0) {
        setGroceryItems([newItem, ...groceryItems]);
        setNewItem({ name: "", quantity: "" });
        // Close the popup after adding the item
        setShowPopup(false);
      } else {
        // Show an error toast
        setShowErrorToast(true);
      }
    }
  };

  const removeItemFromList = (index: number) => {
    const updatedItems = [...groceryItems];
    updatedItems.splice(index, 1);
    setGroceryItems(updatedItems);
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle className="title">Groceries List</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <GroceryList
          groceryItems={groceryItems}
          removeItemFromList={removeItemFromList}
        />
        <IonModal isOpen={showPopup}>
          <IonContent className="center-content">
            <IonToolbar>
              <IonButton slot="end" onClick={() => setShowPopup(false)}>
                X
              </IonButton>
            </IonToolbar>
            <div className="form-container">
              <IonInput
              className="input"
                type="text"
                placeholder="Enter the item name"
                value={newItem.name}
                onIonChange={(e) =>
                  setNewItem({ ...newItem, name: e.detail.value! })
                }
              />
              <IonInput
               className="input"
                type="text"
                placeholder="Enter the quantity"
                value={newItem.quantity}
                onIonChange={(e) =>
                  setNewItem({ ...newItem, quantity: e.detail.value! })
                }
              />
              <IonButton expand="block" onClick={addItemToList}>
                Add
              </IonButton>
            </div>
          </IonContent>
        </IonModal>

        <IonFab vertical="bottom" horizontal="end" slot="fixed">
          <IonFabButton onClick={() => setShowPopup(true)}>
            <IonIcon icon={add} />
          </IonFabButton>
        </IonFab>

        <IonToast
          isOpen={showErrorToast}
          onDidDismiss={() => setShowErrorToast(false)}
          message="Invalid quantity. please enter a valid positive number. e.g 1,2,3..."
          duration={2000} // Duration (2 seconds)
          color="danger" 
        />
      </IonContent>
    </IonPage>
  );
};

export default Grocery;
